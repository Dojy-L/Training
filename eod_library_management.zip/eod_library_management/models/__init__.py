from . import library_book
from . import book_rental
from . import res_partner