from odoo import models,fields,api,_


class EstatePropertyType(models.Model):
    _name = 'estate.property.type'
    _description = 'Estate Property Type'
    _order = "sequence,name"

    name = fields.Char(string="Name")
    sequence = fields.Integer(string="sequence", default=1)