# -*- coding: utf-8 -*-
from odoo import models, fields, api


class EstateProperty(models.Model):
    _name = 'estate.property'
    _description = 'Real estate Properties'

    name = fields.Char(string="Title", required=True)
    active = fields.Boolean(string="Active", default=True)
    description = fields.Char(string="Description")
    postcode = fields.Char(string="Post Code")
    date_availability = fields.Date(string="Date availability")
    expected_price = fields.Float(string="Expected Price", required=True)
    selling_price = fields.Float(string="Selling Price")
    bedrooms = fields.Integer(string="Bedrooms")
    living_area = fields.Integer(string="Living Area")
    facades = fields.Integer(string="Facades")
    garage = fields.Boolean(string="Garage")
    garden = fields.Boolean(string="Garden")
    garden_area = fields.Integer(string="Garden Area")
    garden_orientation = fields.Selection([('north','North'),('south','South'),('east','East'),('west','West')], string="Garden Orientation")
    state = fields.Selection([('new','New'),('received','Offer received'),('accepted','Offer accepted'),
                              ('sold','Sold'),('canceled','Canceled')], required=True, copy=False, default='new')

    property_type_id = fields.Many2one('estate.property.type', string='Property Type')

    partner_id = fields.Many2one('res.partner', string="Buyer")
    user_id = fields.Many2one('res.users', string="Salesman", default=lambda self: self.env.user)

    offer_ids = fields.One2many('estate.property.offer','property_id', string="Offer_ids")
    tag_ids = fields.Many2many('estate.property.tag', string="Tags")